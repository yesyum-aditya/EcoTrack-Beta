# EcoTrack Monolithic Application - Complete Structure

## Directory Structure
```
ecotrack-monolith/
│
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── ecotrack/
│   │   │           ├── EcoTrackApplication.java
│   │   │           │
│   │   │           ├── entity/
│   │   │           │   ├── User.java
│   │   │           │   ├── AuditLog.java
│   │   │           │   ├── Issue.java
│   │   │           │   ├── Resolution.java
│   │   │           │   ├── Sensor.java
│   │   │           │   ├── SensorData.java
│   │   │           │   ├── Analysis.java
│   │   │           │   ├── EmissionLog.java
│   │   │           │   ├── IndustryDocument.java
│   │   │           │   ├── Project.java
│   │   │           │   ├── Milestone.java
│   │   │           │   ├── Impact.java
│   │   │           │   ├── ComplianceRecord.java
│   │   │           │   ├── Audit.java
│   │   │           │   ├── Report.java
│   │   │           │   └── Notification.java
│   │   │           │
│   │   │           ├── repository/
│   │   │           │   ├── UserRepository.java
│   │   │           │   ├── AuditLogRepository.java
│   │   │           │   ├── IssueRepository.java
│   │   │           │   ├── ResolutionRepository.java
│   │   │           │   ├── SensorRepository.java
│   │   │           │   ├── SensorDataRepository.java
│   │   │           │   ├── AnalysisRepository.java
│   │   │           │   ├── EmissionLogRepository.java
│   │   │           │   ├── IndustryDocumentRepository.java
│   │   │           │   ├── ProjectRepository.java
│   │   │           │   ├── MilestoneRepository.java
│   │   │           │   ├── ImpactRepository.java
│   │   │           │   ├── ComplianceRecordRepository.java
│   │   │           │   ├── AuditRepository.java
│   │   │           │   ├── ReportRepository.java
│   │   │           │   └── NotificationRepository.java
│   │   │           │
│   │   │           ├── service/
│   │   │           │   ├── UserService.java
│   │   │           │   ├── IssueService.java
│   │   │           │   ├── SensorService.java
│   │   │           │   ├── EmissionService.java
│   │   │           │   ├── ProjectService.java
│   │   │           │   ├── ComplianceService.java
│   │   │           │   ├── ReportService.java
│   │   │           │   └── NotificationService.java
│   │   │           │
│   │   │           ├── controller/
│   │   │           │   ├── UserController.java
│   │   │           │   ├── IssueController.java
│   │   │           │   ├── SensorController.java
│   │   │           │   ├── EmissionController.java
│   │   │           │   ├── ProjectController.java
│   │   │           │   ├── ComplianceController.java
│   │   │           │   ├── ReportController.java
│   │   │           │   └── NotificationController.java
│   │   │           │
│   │   │           ├── exception/
│   │   │           │   └── GlobalExceptionHandler.java
│   │   │           │
│   │   │           └── config/
│   │   │
│   │   └── resources/
│   │       └── application.properties
│   │
│   └── test/
│       └── java/
│           └── com/
│               └── ecotrack/
│
├── target/                    (generated after build)
├── .gitignore
├── pom.xml
├── README.md
└── PROJECT_STRUCTURE.md
```

## Module Mapping

### Identity & Access Management
- **Entity**: User, AuditLog
- **Service**: UserService
- **Controller**: UserController
- **Endpoints**: /api/users

### Citizen Reporting
- **Entity**: Issue, Resolution
- **Service**: IssueService
- **Controller**: IssueController
- **Endpoints**: /api/issues

### Environmental Monitoring
- **Entity**: Sensor, SensorData, Analysis
- **Service**: SensorService
- **Controller**: SensorController
- **Endpoints**: /api/sensors

### Industry Management
- **Entity**: EmissionLog, IndustryDocument
- **Service**: EmissionService
- **Controller**: EmissionController
- **Endpoints**: /api/emissions

### Sustainability Projects
- **Entity**: Project, Milestone, Impact
- **Service**: ProjectService
- **Controller**: ProjectController
- **Endpoints**: /api/projects

### Compliance & Auditing
- **Entity**: ComplianceRecord, Audit
- **Service**: ComplianceService
- **Controller**: ComplianceController
- **Endpoints**: /api/compliance

### Reporting
- **Entity**: Report
- **Service**: ReportService
- **Controller**: ReportController
- **Endpoints**: /api/reports

### Notifications
- **Entity**: Notification
- **Service**: NotificationService
- **Controller**: NotificationController
- **Endpoints**: /api/notifications

## Technology Stack
- **Java**: 17
- **Spring Boot**: 3.2.0
- **Database**: MySQL 8.0+
- **ORM**: Hibernate/JPA
- **Build Tool**: Maven
- **Lombok**: For reducing boilerplate code

## Design Patterns
- **Layered Architecture**: Controller → Service → Repository → Entity
- **Dependency Injection**: Using Spring's @RequiredArgsConstructor
- **Repository Pattern**: Spring Data JPA repositories
- **DTO Pattern**: Direct entity exposure (can be enhanced with DTOs)
- **Exception Handling**: Global exception handler

## Key Characteristics
✅ Single monolithic application
✅ Single database schema
✅ Single port (8080)
✅ No microservices
✅ No inter-service communication
✅ Clean separation of concerns
✅ RESTful API design
✅ Automatic schema generation
