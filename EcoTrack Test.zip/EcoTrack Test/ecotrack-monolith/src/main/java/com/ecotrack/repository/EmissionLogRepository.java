package com.ecotrack.repository;

import com.ecotrack.entity.EmissionLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmissionLogRepository extends JpaRepository<EmissionLog, Long> {
}
