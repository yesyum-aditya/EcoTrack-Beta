package com.ecotrack.controller;

import com.ecotrack.entity.EmissionLog;
import com.ecotrack.service.EmissionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/emissions")
@RequiredArgsConstructor
@Tag(name = "Emission Management", description = "APIs for managing industry emissions")
public class EmissionController {
    
    private final EmissionService emissionService;
    
    @GetMapping
    public ResponseEntity<List<EmissionLog>> getAllEmissions() {
        return ResponseEntity.ok(emissionService.getAllEmissions());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<EmissionLog> getEmissionById(@PathVariable Long id) {
        return ResponseEntity.ok(emissionService.getEmissionById(id));
    }
    
    @PostMapping
    public ResponseEntity<EmissionLog> createEmission(@RequestBody EmissionLog emission) {
        return ResponseEntity.ok(emissionService.createEmission(emission));
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<EmissionLog> updateEmission(@PathVariable Long id, @RequestBody EmissionLog emission) {
        return ResponseEntity.ok(emissionService.updateEmission(id, emission));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmission(@PathVariable Long id) {
        emissionService.deleteEmission(id);
        return ResponseEntity.noContent().build();
    }
}
