package com.ecotrack.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "resolution")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Resolution {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long resolutionId;
    
    @Column(nullable = false)
    private Long issueId;
    
    @Column(nullable = false)
    private Long officerId;
    
    @Column(nullable = false)
    private String actions;
    
    @Column(nullable = false)
    private LocalDate date;
    
    @Column(nullable = false)
    private String status;
}
