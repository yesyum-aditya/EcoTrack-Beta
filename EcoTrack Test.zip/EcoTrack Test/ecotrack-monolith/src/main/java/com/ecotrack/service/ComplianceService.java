package com.ecotrack.service;

import com.ecotrack.entity.ComplianceRecord;
import com.ecotrack.repository.ComplianceRecordRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ComplianceService {
    
    private final ComplianceRecordRepository complianceRecordRepository;
    
    public List<ComplianceRecord> getAllCompliance() {
        return complianceRecordRepository.findAll();
    }
    
    public ComplianceRecord getComplianceById(Long id) {
        return complianceRecordRepository.findById(id).orElseThrow(() -> new RuntimeException("Compliance not found"));
    }
    
    public ComplianceRecord createCompliance(ComplianceRecord compliance) {
        return complianceRecordRepository.save(compliance);
    }
    
    public ComplianceRecord updateCompliance(Long id, ComplianceRecord compliance) {
        ComplianceRecord existing = getComplianceById(id);
        existing.setEntityId(compliance.getEntityId());
        existing.setType(compliance.getType());
        existing.setResult(compliance.getResult());
        existing.setDate(compliance.getDate());
        existing.setNotes(compliance.getNotes());
        return complianceRecordRepository.save(existing);
    }
    
    public void deleteCompliance(Long id) {
        complianceRecordRepository.deleteById(id);
    }
}
