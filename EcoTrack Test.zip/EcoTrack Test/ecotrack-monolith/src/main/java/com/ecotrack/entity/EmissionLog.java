package com.ecotrack.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "emission_log")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmissionLog {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long logId;
    
    @Column(nullable = false)
    private Long industryId;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EmissionType type;
    
    @Column(nullable = false)
    private BigDecimal quantity;
    
    @Column(nullable = false)
    private LocalDate date;
    
    @Column(nullable = false)
    private String status;
    
    public enum EmissionType {
        CO2, NOx, SOx
    }
}
