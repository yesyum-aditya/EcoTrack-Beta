package com.ecotrack.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "issue")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Issue {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long issueId;
    
    @Column(nullable = false)
    private Long citizenId;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private IssueType type;
    
    @Column(nullable = false)
    private String location;
    
    @Column(nullable = false)
    private LocalDate date;
    
    @Column(nullable = false)
    private String status;
    
    public enum IssueType {
        POLLUTION, WASTE, DEFORESTATION
    }
}
