package com.ecotrack.service;

import com.ecotrack.entity.Notification;
import com.ecotrack.repository.NotificationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NotificationService {
    
    private final NotificationRepository notificationRepository;
    
    public List<Notification> getAllNotifications() {
        return notificationRepository.findAll();
    }
    
    public Notification getNotificationById(Long id) {
        return notificationRepository.findById(id).orElseThrow(() -> new RuntimeException("Notification not found"));
    }
    
    public Notification createNotification(Notification notification) {
        return notificationRepository.save(notification);
    }
    
    public Notification updateNotification(Long id, Notification notification) {
        Notification existing = getNotificationById(id);
        existing.setUserId(notification.getUserId());
        existing.setEntityId(notification.getEntityId());
        existing.setMessage(notification.getMessage());
        existing.setCategory(notification.getCategory());
        existing.setStatus(notification.getStatus());
        return notificationRepository.save(existing);
    }
    
    public void deleteNotification(Long id) {
        notificationRepository.deleteById(id);
    }
}
