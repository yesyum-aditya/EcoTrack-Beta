package com.ecotrack.repository;

import com.ecotrack.entity.IndustryDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IndustryDocumentRepository extends JpaRepository<IndustryDocument, Long> {
}
