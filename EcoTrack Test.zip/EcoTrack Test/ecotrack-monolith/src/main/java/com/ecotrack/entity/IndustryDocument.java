package com.ecotrack.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "industry_document")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IndustryDocument {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long documentId;
    
    @Column(nullable = false)
    private Long industryId;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private DocType docType;
    
    @Column(nullable = false)
    private String fileURI;
    
    @Column(nullable = false)
    private LocalDate uploadedDate;
    
    @Column(nullable = false)
    private String verificationStatus;
    
    public enum DocType {
        PERMIT, COMPLIANCE
    }
}
