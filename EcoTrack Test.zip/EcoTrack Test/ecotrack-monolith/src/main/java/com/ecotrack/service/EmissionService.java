package com.ecotrack.service;

import com.ecotrack.entity.EmissionLog;
import com.ecotrack.repository.EmissionLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class EmissionService {
    
    private final EmissionLogRepository emissionLogRepository;
    
    public List<EmissionLog> getAllEmissions() {
        return emissionLogRepository.findAll();
    }
    
    public EmissionLog getEmissionById(Long id) {
        return emissionLogRepository.findById(id).orElseThrow(() -> new RuntimeException("Emission not found"));
    }
    
    public EmissionLog createEmission(EmissionLog emission) {
        return emissionLogRepository.save(emission);
    }
    
    public EmissionLog updateEmission(Long id, EmissionLog emission) {
        EmissionLog existing = getEmissionById(id);
        existing.setIndustryId(emission.getIndustryId());
        existing.setType(emission.getType());
        existing.setQuantity(emission.getQuantity());
        existing.setDate(emission.getDate());
        existing.setStatus(emission.getStatus());
        return emissionLogRepository.save(existing);
    }
    
    public void deleteEmission(Long id) {
        emissionLogRepository.deleteById(id);
    }
}
