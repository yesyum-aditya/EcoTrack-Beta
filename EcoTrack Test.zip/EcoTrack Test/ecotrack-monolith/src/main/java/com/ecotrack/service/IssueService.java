package com.ecotrack.service;

import com.ecotrack.entity.Issue;
import com.ecotrack.repository.IssueRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class IssueService {
    
    private final IssueRepository issueRepository;
    
    public List<Issue> getAllIssues() {
        return issueRepository.findAll();
    }
    
    public Issue getIssueById(Long id) {
        return issueRepository.findById(id).orElseThrow(() -> new RuntimeException("Issue not found"));
    }
    
    public Issue createIssue(Issue issue) {
        return issueRepository.save(issue);
    }
    
    public Issue updateIssue(Long id, Issue issue) {
        Issue existing = getIssueById(id);
        existing.setCitizenId(issue.getCitizenId());
        existing.setType(issue.getType());
        existing.setLocation(issue.getLocation());
        existing.setDate(issue.getDate());
        existing.setStatus(issue.getStatus());
        return issueRepository.save(existing);
    }
    
    public void deleteIssue(Long id) {
        issueRepository.deleteById(id);
    }
}
