package com.ecotrack.service;

import com.ecotrack.entity.Report;
import com.ecotrack.repository.ReportRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReportService {
    
    private final ReportRepository reportRepository;
    
    public List<Report> getAllReports() {
        return reportRepository.findAll();
    }
    
    public Report getReportById(Long id) {
        return reportRepository.findById(id).orElseThrow(() -> new RuntimeException("Report not found"));
    }
    
    public Report createReport(Report report) {
        return reportRepository.save(report);
    }
    
    public Report updateReport(Long id, Report report) {
        Report existing = getReportById(id);
        existing.setScope(report.getScope());
        existing.setMetrics(report.getMetrics());
        existing.setGeneratedDate(report.getGeneratedDate());
        return reportRepository.save(existing);
    }
    
    public void deleteReport(Long id) {
        reportRepository.deleteById(id);
    }
}
