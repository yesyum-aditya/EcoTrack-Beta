package com.ecotrack.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "impact")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Impact {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long impactId;
    
    @Column(nullable = false)
    private Long projectId;
    
    @Column(columnDefinition = "TEXT")
    private String metricsJSON;
    
    @Column(nullable = false)
    private LocalDate date;
    
    @Column(nullable = false)
    private String status;
}
