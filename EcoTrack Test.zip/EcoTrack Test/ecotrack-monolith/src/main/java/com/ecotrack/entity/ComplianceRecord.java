package com.ecotrack.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "compliance_record")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ComplianceRecord {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long complianceId;
    
    @Column(nullable = false)
    private Long entityId;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ComplianceType type;
    
    @Column(nullable = false)
    private String result;
    
    @Column(nullable = false)
    private LocalDate date;
    
    @Column(columnDefinition = "TEXT")
    private String notes;
    
    public enum ComplianceType {
        EMISSION, PROJECT, POLICY
    }
}
