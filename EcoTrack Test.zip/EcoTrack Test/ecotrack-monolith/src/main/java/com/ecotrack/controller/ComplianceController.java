package com.ecotrack.controller;

import com.ecotrack.entity.ComplianceRecord;
import com.ecotrack.service.ComplianceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/compliance")
@RequiredArgsConstructor
@Tag(name = "Compliance Management", description = "APIs for managing compliance records and audits")
public class ComplianceController {
    
    private final ComplianceService complianceService;
    
    @GetMapping
    public ResponseEntity<List<ComplianceRecord>> getAllCompliance() {
        return ResponseEntity.ok(complianceService.getAllCompliance());
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<ComplianceRecord> getComplianceById(@PathVariable Long id) {
        return ResponseEntity.ok(complianceService.getComplianceById(id));
    }
    
    @PostMapping
    public ResponseEntity<ComplianceRecord> createCompliance(@RequestBody ComplianceRecord compliance) {
        return ResponseEntity.ok(complianceService.createCompliance(compliance));
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<ComplianceRecord> updateCompliance(@PathVariable Long id, @RequestBody ComplianceRecord compliance) {
        return ResponseEntity.ok(complianceService.updateCompliance(id, compliance));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCompliance(@PathVariable Long id) {
        complianceService.deleteCompliance(id);
        return ResponseEntity.noContent().build();
    }
}
