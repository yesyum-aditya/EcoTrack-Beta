package com.ecotrack.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenApiConfig {
    
    @Bean
    public OpenAPI ecoTrackOpenAPI() {
        Server server = new Server();
        server.setUrl("http://localhost:8085");
        server.setDescription("EcoTrack Development Server");
        
        Contact contact = new Contact();
        contact.setName("EcoTrack Team");
        contact.setEmail("support@ecotrack.com");
        
        License license = new License()
                .name("Apache 2.0")
                .url("https://www.apache.org/licenses/LICENSE-2.0.html");
        
        Info info = new Info()
                .title("EcoTrack API")
                .version("1.0.0")
                .description("Environmental Monitoring & Sustainability Management System API")
                .contact(contact)
                .license(license);
        
        return new OpenAPI()
                .info(info)
                .servers(List.of(server));
    }
}
