package com.ecotrack.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "report")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Report {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long reportId;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ReportScope scope;
    
    @Column(columnDefinition = "TEXT")
    private String metrics;
    
    @Column(nullable = false)
    private LocalDate generatedDate;
    
    public enum ReportScope {
        ISSUE, EMISSION, PROJECT, COMPLIANCE
    }
}
