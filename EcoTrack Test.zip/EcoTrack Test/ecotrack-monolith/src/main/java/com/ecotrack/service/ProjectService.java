package com.ecotrack.service;

import com.ecotrack.entity.Project;
import com.ecotrack.repository.ProjectRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProjectService {
    
    private final ProjectRepository projectRepository;
    
    public List<Project> getAllProjects() {
        return projectRepository.findAll();
    }
    
    public Project getProjectById(Long id) {
        return projectRepository.findById(id).orElseThrow(() -> new RuntimeException("Project not found"));
    }
    
    public Project createProject(Project project) {
        return projectRepository.save(project);
    }
    
    public Project updateProject(Long id, Project project) {
        Project existing = getProjectById(id);
        existing.setTitle(project.getTitle());
        existing.setDescription(project.getDescription());
        existing.setStartDate(project.getStartDate());
        existing.setEndDate(project.getEndDate());
        existing.setBudget(project.getBudget());
        existing.setStatus(project.getStatus());
        return projectRepository.save(existing);
    }
    
    public void deleteProject(Long id) {
        projectRepository.deleteById(id);
    }
}
