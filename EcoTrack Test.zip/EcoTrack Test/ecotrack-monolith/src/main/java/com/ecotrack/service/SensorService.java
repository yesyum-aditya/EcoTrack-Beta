package com.ecotrack.service;

import com.ecotrack.entity.Sensor;
import com.ecotrack.repository.SensorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SensorService {
    
    private final SensorRepository sensorRepository;
    
    public List<Sensor> getAllSensors() {
        return sensorRepository.findAll();
    }
    
    public Sensor getSensorById(Long id) {
        return sensorRepository.findById(id).orElseThrow(() -> new RuntimeException("Sensor not found"));
    }
    
    public Sensor createSensor(Sensor sensor) {
        return sensorRepository.save(sensor);
    }
    
    public Sensor updateSensor(Long id, Sensor sensor) {
        Sensor existing = getSensorById(id);
        existing.setLocation(sensor.getLocation());
        existing.setType(sensor.getType());
        existing.setStatus(sensor.getStatus());
        return sensorRepository.save(existing);
    }
    
    public void deleteSensor(Long id) {
        sensorRepository.deleteById(id);
    }
}
