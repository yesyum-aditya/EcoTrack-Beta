# Swagger/OpenAPI Documentation Guide

## 🎯 Overview

The EcoTrack application now includes **Swagger/OpenAPI 3.0** for interactive API documentation and testing.

## 🌐 Access URLs

After starting the application, access Swagger at:

- **Swagger UI (Interactive)**: `http://localhost:8085/swagger-ui.html`
- **OpenAPI JSON**: `http://localhost:8085/api-docs`
- **OpenAPI YAML**: `http://localhost:8085/api-docs.yaml`

## 📚 API Groups

The Swagger UI organizes APIs into the following groups:

### 1. **User Management**
- Manage users in the EcoTrack system
- Endpoints: `/api/users`

### 2. **Issue Management**
- Manage citizen-reported environmental issues
- Endpoints: `/api/issues`

### 3. **Sensor Management**
- Manage environmental sensors
- Endpoints: `/api/sensors`

### 4. **Emission Management**
- Manage industry emissions
- Endpoints: `/api/emissions`

### 5. **Project Management**
- Manage sustainability projects
- Endpoints: `/api/projects`

### 6. **Compliance Management**
- Manage compliance records and audits
- Endpoints: `/api/compliance`

### 7. **Report Management**
- Generate and manage system reports
- Endpoints: `/api/reports`

### 8. **Notification Management**
- Manage user notifications
- Endpoints: `/api/notifications`

## 🚀 How to Use Swagger UI

### Step 1: Start the Application
```bash
mvn spring-boot:run
```

### Step 2: Open Swagger UI
Navigate to: `http://localhost:8085/swagger-ui.html`

### Step 3: Explore APIs
- Click on any API group to expand
- Click on an endpoint to see details
- Click "Try it out" to test the API

### Step 4: Test an API
1. Click "Try it out" button
2. Fill in the required parameters
3. Click "Execute"
4. View the response below

## 📋 Example: Testing User API

### Create a User (POST)
1. Navigate to **User Management** section
2. Click on `POST /api/users`
3. Click "Try it out"
4. Enter request body:
```json
{
  "name": "John Doe",
  "role": "CITIZEN",
  "email": "john.doe@example.com",
  "phone": "1234567890",
  "status": "ACTIVE"
}
```
5. Click "Execute"
6. View the response with created user details

### Get All Users (GET)
1. Click on `GET /api/users`
2. Click "Try it out"
3. Click "Execute"
4. View the list of all users

### Get User by ID (GET)
1. Click on `GET /api/users/{id}`
2. Click "Try it out"
3. Enter user ID (e.g., 1)
4. Click "Execute"
5. View the user details

### Update User (PUT)
1. Click on `PUT /api/users/{id}`
2. Click "Try it out"
3. Enter user ID
4. Enter updated user data
5. Click "Execute"

### Delete User (DELETE)
1. Click on `DELETE /api/users/{id}`
2. Click "Try it out"
3. Enter user ID
4. Click "Execute"

## 🎨 Swagger UI Features

### 1. **Interactive Testing**
- Test all APIs directly from the browser
- No need for external tools like Postman

### 2. **Request/Response Examples**
- View example requests and responses
- Understand data structures

### 3. **Schema Documentation**
- View entity schemas
- Understand field types and constraints

### 4. **Authentication Support**
- Add authentication headers if needed
- Test secured endpoints

### 5. **Export Options**
- Download OpenAPI specification
- Import into other tools

## 📊 API Endpoints Summary

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/users` | Get all users |
| GET | `/api/users/{id}` | Get user by ID |
| POST | `/api/users` | Create new user |
| PUT | `/api/users/{id}` | Update user |
| DELETE | `/api/users/{id}` | Delete user |
| GET | `/api/issues` | Get all issues |
| GET | `/api/issues/{id}` | Get issue by ID |
| POST | `/api/issues` | Create new issue |
| PUT | `/api/issues/{id}` | Update issue |
| DELETE | `/api/issues/{id}` | Delete issue |
| GET | `/api/sensors` | Get all sensors |
| GET | `/api/sensors/{id}` | Get sensor by ID |
| POST | `/api/sensors` | Create new sensor |
| PUT | `/api/sensors/{id}` | Update sensor |
| DELETE | `/api/sensors/{id}` | Delete sensor |
| GET | `/api/emissions` | Get all emissions |
| GET | `/api/emissions/{id}` | Get emission by ID |
| POST | `/api/emissions` | Create new emission |
| PUT | `/api/emissions/{id}` | Update emission |
| DELETE | `/api/emissions/{id}` | Delete emission |
| GET | `/api/projects` | Get all projects |
| GET | `/api/projects/{id}` | Get project by ID |
| POST | `/api/projects` | Create new project |
| PUT | `/api/projects/{id}` | Update project |
| DELETE | `/api/projects/{id}` | Delete project |
| GET | `/api/compliance` | Get all compliance records |
| GET | `/api/compliance/{id}` | Get compliance by ID |
| POST | `/api/compliance` | Create compliance record |
| PUT | `/api/compliance/{id}` | Update compliance |
| DELETE | `/api/compliance/{id}` | Delete compliance |
| GET | `/api/reports` | Get all reports |
| GET | `/api/reports/{id}` | Get report by ID |
| POST | `/api/reports` | Create new report |
| PUT | `/api/reports/{id}` | Update report |
| DELETE | `/api/reports/{id}` | Delete report |
| GET | `/api/notifications` | Get all notifications |
| GET | `/api/notifications/{id}` | Get notification by ID |
| POST | `/api/notifications` | Create notification |
| PUT | `/api/notifications/{id}` | Update notification |
| DELETE | `/api/notifications/{id}` | Delete notification |

## 🔧 Configuration

Swagger configuration is located in:
- **Config Class**: `src/main/java/com/ecotrack/config/OpenApiConfig.java`
- **Properties**: `src/main/resources/application.properties`

### Application Properties
```properties
# Swagger/OpenAPI Configuration
springdoc.api-docs.path=/api-docs
springdoc.swagger-ui.path=/swagger-ui.html
springdoc.swagger-ui.enabled=true
springdoc.swagger-ui.operationsSorter=method
springdoc.swagger-ui.tagsSorter=alpha
```

## 📦 Dependencies

Swagger is provided by SpringDoc OpenAPI:
```xml
<dependency>
    <groupId>org.springdoc</groupId>
    <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
    <version>2.3.0</version>
</dependency>
```

## 🎯 Benefits

1. **Interactive Documentation** - Test APIs without external tools
2. **Auto-Generated** - Documentation updates automatically with code changes
3. **Standard Format** - OpenAPI 3.0 specification
4. **Easy Integration** - Export to Postman, Insomnia, etc.
5. **Developer Friendly** - Clear API contracts for frontend developers

## 🔗 Additional Resources

- **SpringDoc Documentation**: https://springdoc.org/
- **OpenAPI Specification**: https://swagger.io/specification/
- **Swagger UI**: https://swagger.io/tools/swagger-ui/

## 🎉 Quick Start

1. Start the application: `mvn spring-boot:run`
2. Open browser: `http://localhost:8085/swagger-ui.html`
3. Explore and test APIs!

---

**Note**: Make sure MySQL is running and the database is configured before testing the APIs.
