# 🚀 EcoTrack Quick Reference Card

## 📍 Application Details
- **Port**: `8085`
- **Base URL**: `http://localhost:8085`
- **Database**: MySQL (`ecotrack_db`)

## 🌐 Important URLs

| Service | URL |
|---------|-----|
| **Application** | http://localhost:8085 |
| **Swagger UI** | http://localhost:8085/swagger-ui.html |
| **API Docs (JSON)** | http://localhost:8085/api-docs |
| **API Docs (YAML)** | http://localhost:8085/api-docs.yaml |

## 🎯 API Endpoints

| Module | Endpoint | Description |
|--------|----------|-------------|
| Users | `/api/users` | User management |
| Issues | `/api/issues` | Citizen issues |
| Sensors | `/api/sensors` | Environmental sensors |
| Emissions | `/api/emissions` | Industry emissions |
| Projects | `/api/projects` | Sustainability projects |
| Compliance | `/api/compliance` | Compliance records |
| Reports | `/api/reports` | System reports |
| Notifications | `/api/notifications` | User notifications |

## 🚀 Quick Start Commands

### Build Project
```bash
mvn clean install
```

### Run Application
```bash
mvn spring-boot:run
```

### Access Swagger
```
http://localhost:8085/swagger-ui.html
```

## 🗄️ Database Configuration

**File**: `src/main/resources/application.properties`

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/ecotrack_db
spring.datasource.username=root
spring.datasource.password=root
```

## 📦 Key Dependencies

- Spring Boot 3.2.0
- Spring Data JPA
- MySQL Connector
- Lombok
- SpringDoc OpenAPI 2.3.0

## 📁 Project Structure

```
com.ecotrack/
├── entity/          # 16 entities
├── repository/      # 16 repositories
├── service/         # 8 services
├── controller/      # 8 controllers
├── config/          # Configuration
└── exception/       # Exception handling
```

## 🎨 Entity List

1. User
2. AuditLog
3. Issue
4. Resolution
5. Sensor
6. SensorData
7. Analysis
8. EmissionLog
9. IndustryDocument
10. Project
11. Milestone
12. Impact
13. ComplianceRecord
14. Audit
15. Report
16. Notification

## 🔧 Common Operations

### Test API with cURL
```bash
# Get all users
curl http://localhost:8085/api/users

# Create user
curl -X POST http://localhost:8085/api/users \
  -H "Content-Type: application/json" \
  -d '{"name":"John","role":"CITIZEN","email":"john@test.com","phone":"123","status":"ACTIVE"}'
```

## 📚 Documentation Files

- `README.md` - Complete guide
- `PROJECT_STRUCTURE.md` - Architecture details
- `SWAGGER_GUIDE.md` - API documentation guide
- `INTEGRATION_SUMMARY.md` - Integration details
- `QUICK_REFERENCE.md` - This file

## ✅ Pre-flight Checklist

- [ ] MySQL is running
- [ ] Database password updated in `application.properties`
- [ ] Project built successfully (`mvn clean install`)
- [ ] Application started (`mvn spring-boot:run`)
- [ ] Swagger UI accessible at http://localhost:8085/swagger-ui.html

## 🆘 Troubleshooting

| Issue | Solution |
|-------|----------|
| Port already in use | Change port in `application.properties` |
| Database connection error | Check MySQL is running and credentials are correct |
| Build fails | Run `mvn clean install -U` |
| Swagger not loading | Ensure application started successfully |

## 📞 Support

For issues or questions, refer to:
- README.md for detailed setup
- SWAGGER_GUIDE.md for API testing
- PROJECT_STRUCTURE.md for architecture

---

**Last Updated**: 2024
**Version**: 1.0.0
