# EcoTrack Monolithic Application

## Overview
EcoTrack is a comprehensive Environmental Monitoring & Sustainability Management System built as a monolithic Spring Boot application.

## Architecture
- **Type**: Monolithic Application
- **Framework**: Spring Boot 3.2.0
- **Database**: MySQL
- **Port**: 8085
- **API Documentation**: Swagger/OpenAPI 3.0

## Project Structure
```
com.ecotrack
├── entity/              # All JPA entities
├── repository/          # Spring Data JPA repositories
├── service/             # Business logic layer
├── controller/          # REST API controllers
├── exception/           # Global exception handling
└── config/              # Configuration classes
```

## Entities
1. **User** - User management (Citizen/Agency/Industry/Scientist/Admin/Compliance)
2. **AuditLog** - System audit logging
3. **Issue** - Citizen-reported issues (Pollution/Waste/Deforestation)
4. **Resolution** - Issue resolutions
5. **Sensor** - Environmental sensors (Air/Water/Noise)
6. **SensorData** - Sensor readings
7. **Analysis** - Scientific analysis of sensor data
8. **EmissionLog** - Industry emissions (CO2/NOx/SOx)
9. **IndustryDocument** - Industry compliance documents
10. **Project** - Sustainability projects
11. **Milestone** - Project milestones
12. **Impact** - Project impact metrics
13. **ComplianceRecord** - Compliance records
14. **Audit** - Compliance audits
15. **Report** - System reports
16. **Notification** - User notifications

## REST API Endpoints

### Users
- GET    /api/users
- GET    /api/users/{id}
- POST   /api/users
- PUT    /api/users/{id}
- DELETE /api/users/{id}

### Issues
- GET    /api/issues
- GET    /api/issues/{id}
- POST   /api/issues
- PUT    /api/issues/{id}
- DELETE /api/issues/{id}

### Sensors
- GET    /api/sensors
- GET    /api/sensors/{id}
- POST   /api/sensors
- PUT    /api/sensors/{id}
- DELETE /api/sensors/{id}

### Emissions
- GET    /api/emissions
- GET    /api/emissions/{id}
- POST   /api/emissions
- PUT    /api/emissions/{id}
- DELETE /api/emissions/{id}

### Projects
- GET    /api/projects
- GET    /api/projects/{id}
- POST   /api/projects
- PUT    /api/projects/{id}
- DELETE /api/projects/{id}

### Compliance
- GET    /api/compliance
- GET    /api/compliance/{id}
- POST   /api/compliance
- PUT    /api/compliance/{id}
- DELETE /api/compliance/{id}

### Reports
- GET    /api/reports
- GET    /api/reports/{id}
- POST   /api/reports
- PUT    /api/reports/{id}
- DELETE /api/reports/{id}

### Notifications
- GET    /api/notifications
- GET    /api/notifications/{id}
- POST   /api/notifications
- PUT    /api/notifications/{id}
- DELETE /api/notifications/{id}

## Prerequisites
- Java 17 or higher
- Maven 3.6+
- MySQL 8.0+

## Database Setup
1. Install MySQL
2. Create database (auto-created by application):
```sql
CREATE DATABASE ecotrack_db;
```

3. Update credentials in `application.properties`:
```properties
spring.datasource.username=root
spring.datasource.password=YOUR_PASSWORD
```

## Build & Run

### Using Maven
```bash
# Build the project
mvn clean install

# Run the application
mvn spring-boot:run
```

### Using JAR
```bash
# Build JAR
mvn clean package

# Run JAR
java -jar target/ecotrack-monolith-1.0.0.jar
```

## Configuration
All configuration is in `src/main/resources/application.properties`:
- Database connection
- JPA/Hibernate settings
- Server port
- Logging levels

## Database Schema
The application uses `spring.jpa.hibernate.ddl-auto=update` which automatically creates/updates tables based on entity definitions.

## Key Features
✅ Single monolithic application
✅ Single database (MySQL)
✅ Single port (8080)
✅ Internal service communication
✅ Clean layered architecture
✅ RESTful API design
✅ Global exception handling
✅ Automatic schema generation

## Testing
Access the application at: `http://localhost:8085`

### Swagger UI
Interactive API documentation is available at:
- **Swagger UI**: `http://localhost:8085/swagger-ui.html`
- **API Docs (JSON)**: `http://localhost:8085/api-docs`

Example API call:
```bash
curl -X GET http://localhost:8085/api/users
```

## Dependencies
- spring-boot-starter-web
- spring-boot-starter-data-jpa
- spring-boot-starter-validation
- mysql-connector-j
- lombok

## Notes
- All modules are integrated into a single application
- No microservices architecture
- No inter-service REST calls
- All communication happens through service layer
- Single application.properties file
- Single database schema
